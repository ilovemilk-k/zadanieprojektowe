/* komentarz */
#include <stdio.h>

int main()
{
    printf("Witaj świecie listingów!\n");
    return 0;
}

void pustaFunkcja() {    
}