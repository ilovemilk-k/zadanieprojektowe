# Szablon LaTeX pracy dyplomowej Wydziału Elektrotechniki i Informatyki Politechniki Rzeszowskiej

Repozytorium zawiera plik stylu oraz szablon pracy dyplomowej utworzony zgodnie ze standardami merytorycznymi wymaganymi na Wydziale Elektrotechniki i Informatyki Politechniki Rzeszowskiej.

Aby pobrać projekt należy:

- Sposób 1:

  Przycisnąć zielony przycisk ''Code'' (prawy górny róg strony) i wybrać "Download ZIP".

- Sposób 2:
  Kliknąć w poniższy link:
  [https://github.com/przemarbor/szablon_pracy_dyplomowej_weii/zipball/master/](https://github.com/przemarbor/szablon_pracy_dyplomowej_weii/zipball/master/)
  
- Sposób 3:
   
  Wykonać polecenie:
   
      git clone https://github.com/przemarbor/szablon_pracy_dyplomowej_weii/
